import { Component } from "react";

class App extends Component{
    state = {
        user : {
            uname : '',
            uage : 0,
            uemail : ''
        },
        userAgeError : ''
    }
    /* 
    usernameChangeHandler = (evt)=> {
        this.setState({
            user : {
                ...this.state.user,
                uname : evt.target.value
            }
        })
    }
    userageChangeHandler = (evt)=> {
        this.setState({
            user : {
                ...this.state.user,
                uage : evt.target.value
            }
        })        
    }
    usermailChangeHandler = (evt)=> {
        this.setState({
            user : {
                ...this.state.user,
                uemail : evt.target.value
            }
        })
    } 
    */
    formSubmitHandler = (evt) => {
        evt.preventDefault();
        // console.log(evt.target.uage.value, evt.target.uname.value, evt.target.uemail.value);
        if(this.state.user.uage < 18){
            this.setState({ userAgeError : "you are too young to join us" })
        }else if(this.state.user.uage > 90){
            this.setState({ userAgeError : "you are too old to join us" })
        }else{
            this.setState({ userAgeError : "" });
            evt.target.submit();
        }
    }
    changeHandler = (evt)=> {
        this.setState({
            user : {
                ...this.state.user,
                [evt.target.id] : evt.target.value
            }
        })
    }
    render(){
        return <div>
                   <h1 style={ { textAlign : "center "} }>User Registeration</h1>
                   <form onSubmit={this.formSubmitHandler}>
                        <label htmlFor="uname">User Name : </label>
                        <input onChange={ this.changeHandler } value={this.state.user.uname} name="username" id="uname" />
                        <br />
                        <label htmlFor="uage">User Age : </label>
                        <input onChange={ this.changeHandler } value={this.state.user.uage} name="userage" id="uage" />
                            { this.state.userAgeError !== "" && <span>{ this.state.userAgeError }</span> }
                        <br />
                        <label htmlFor="uemail">User eMail : </label>
                        <input onChange={ this.changeHandler } value={this.state.user.uemail} name="usermail" id="uemail" />
                        <br />
                        <button>Submit</button>
                   </form>
                   <ul>
                    <li>User Name : { this.state.user.uname } </li>
                    <li>User Age : { this.state.user.uage } </li>
                    <li>User eMail : { this.state.user.uemail } </li>
                   </ul>
               </div>
    }
}

export default App;