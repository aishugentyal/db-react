import { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    state = {
        power : 0,
        title : "default title"
    }
    increaseHandler = ()=>{
        this.setState({
            power : this.state.power+1
        })
    }
    decreaseHandler = ()=>{
        this.setState({
            power : this.state.power-1
        })
    }
    setTitle = (ntitle) =>{
        this.setState({
            title : ntitle
        })
    }
    render(){
        return <div>
                   <h1>App Component</h1>
                   <h1>Title : { this.state.title }</h1>
                   <button onClick={ this.increaseHandler }>Increase Power</button>
                   <button onClick={ this.decreaseHandler }>Decrease Power</button>
                   <ChildComp changeTitle={ this.setTitle } pow={ this.state.power }>
                        <h3>Hello there</h3>
                        <button>Click Me</button>
                   </ChildComp>
               </div>
    }
}

export default App;