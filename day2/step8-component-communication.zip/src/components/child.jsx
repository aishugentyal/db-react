import React, { Component } from "react";

class ChildComp extends Component{
    ipRef = React.createRef();
    render(){
        return <div style={ { border : "2px solid grey", padding : "10px" } }>
                    <h2>Child Component </h2>
                    { this.props.children }
                    <h3>Power sent from parent is : { this.props.pow }</h3>
                    <input ref={ this.ipRef } type="text" />
                    <button onClick={()=> this.props.changeTitle( this.ipRef.current.value ) }>Change Title</button>
               </div>
    }
}

export default ChildComp;