import { Component } from "react";
import boxStyle from "./mystyle";
import clientBox from "./client.module.css";
import "./mystyle.css";

class App extends Component{
    render(){
        // let boxStyle = { backgroundColor : "crimson", color : "papayawhip", padding : "10px", margin : "10px" };
        return <div>
                   <h1>App Component</h1>
                   {/*  
                  <div style={ { backgroundColor : "crimson", color : "papayawhip", padding : "10px", margin : "10px" } }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic et distinctio magnam perferendis dolorem ullam exercitationem ad quasi molestias animi, fugiat dolor quisquam error at odit facilis quam natus consequatur.
                  </div> 
                   */}
                   <div style={ boxStyle }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic et distinctio magnam perferendis dolorem ullam exercitationem ad quasi molestias animi, fugiat dolor quisquam error at odit facilis quam natus consequatur.
                   </div>
                   <div style={ boxStyle }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic et distinctio magnam perferendis dolorem ullam exercitationem ad quasi molestias animi, fugiat dolor quisquam error at odit facilis quam natus consequatur.
                   </div>
                   <div style={ {...boxStyle, backgroundColor : "darkgray"} }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic et distinctio magnam perferendis dolorem ullam exercitationem ad quasi molestias animi, fugiat dolor quisquam error at odit facilis quam natus consequatur.
                   </div>
                   <hr />
                   <div className="box">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, ipsa totam. Aperiam optio quidem quis delectus. Eos officiis ex maxime est. Ex voluptatem quos vitae laboriosam, quod mollitia. Aspernatur, non?
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reprehenderit deserunt facilis quos doloribus! Corrupti nobis ea aut atque, explicabo odio consectetur nesciunt dignissimos deserunt maxime molestiae reiciendis, iusto laboriosam facilis.
                   </div>
                   <div className={ clientBox.box }>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, ipsa totam. Aperiam optio quidem quis delectus. Eos officiis ex maxime est. Ex voluptatem quos vitae laboriosam, quod mollitia. Aspernatur, non?
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reprehenderit deserunt facilis quos doloribus! Corrupti nobis ea aut atque, explicabo odio consectetur nesciunt dignissimos deserunt maxime molestiae reiciendis, iusto laboriosam facilis.
                   </div>
                   <div className={ 'box' }>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, ipsa totam. Aperiam optio quidem quis delectus. Eos officiis ex maxime est. Ex voluptatem quos vitae laboriosam, quod mollitia. Aspernatur, non?
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reprehenderit deserunt facilis quos doloribus! Corrupti nobis ea aut atque, explicabo odio consectetur nesciunt dignissimos deserunt maxime molestiae reiciendis, iusto laboriosam facilis.
                   </div>
               </div>
    }
}

export default App;