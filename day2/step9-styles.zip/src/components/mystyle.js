function setColor(){
    let colors = ["crimson","darkolivegreen","darkorchid","darkgray"]
    return colors[Math.round(Math.random() * 3)];
}
let boxStyle = { 
    backgroundColor : setColor(), 
    color : "papayawhip", 
    padding : "10px", 
    margin : "10px" 
};

export default boxStyle;