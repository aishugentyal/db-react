import { Component } from "react";
/* 
1. JSX must return a single root element or a component
2. Self closing tags needs to be closed eg <br/> <hr/> <img/> 
3. if you need to return multiple element and don't want to wrap them in a div use React.Fragment or <>;
4. intropolation using { 2 + 3  } 
5. use className instead of class attribute
6. htmlFor instead of for attribute on lable html elements
7. use defaultValue instead of value on input element to create uncontrolled inputs
8. use camel cased so refer type for events for eg, onClick, onMouseOver
9. while using inline style use a config object
10. style properties should be camel cased
11. elements name begin with lowercase like h1, div, img, input, button etc
12. jsx classes, function names must begin with uppercase characters like Panel, UserForm, Datagrid etc
 */
class App extends Component{
    state = {
        power : 10
    }
    render(){
        return <div style={ { width: "400px", backgroundColor: "chocolate", padding: "10px", margin: "auto"} } className="box">
                   <h1>App Component</h1>
                   <h2>Power is : { this.state.power }</h2>
                   <label htmlFor="uname">User Name : </label>
                   {/* <input onChange={(evt)=> this.setState({ power : Number(evt.target.value) })} value={ this.state.power } type="number" id="uname" /> */}
                   <input defaultValue={ this.state.power } type="number" id="uname" />
               </div>
    }
}

export default App;