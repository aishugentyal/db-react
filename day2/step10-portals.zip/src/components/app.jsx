import { Component } from "react";
import PopUp from "./popup";

class App extends Component{
    state = {
        showpopup : false
    }
    showHide = ()=> {
        this.setState({
            showpopup : !this.state.showpopup
        })
    }
    render(){
        return <div>
                   <h1>App Component</h1>
                   { 
                   this.state.showpopup ? <PopUp>
                                                    <div>
                                                        <h1>PopUp Component</h1>
                                                        <button onClick={ this.showHide }>Hide Popup</button>
                                                    </div>
                                            </PopUp> : <button onClick={ this.showHide }>Show Popup</button>
                   }
               </div>
    }
}

export default App;