import { Component } from "react";

class Second extends Component{
    render(){
        return <div style={ { border : "1px solid grey", margin : "10px",  padding : "10px"} }>
                   <h2>Second Component</h2>
                   <h3>Version is { this.props.version }</h3>
               </div>
    }
}

export default Second;