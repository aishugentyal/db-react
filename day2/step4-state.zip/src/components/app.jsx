import { Component } from "react";
import Child from "./child";
import Second from "./second";

/* 
class App extends Component{
    parentVersion = 101;
    render(){
        return <div>
                   <h1>App Component : version { this.parentVersion }</h1>
                   <Child version={ this.parentVersion }/>
                   <Second version={ this.parentVersion }/>
                   <button onClick={()=>{
                    this.parentVersion = this.parentVersion + 1;
                    console.log(this.parentVersion);
                    this.forceUpdate();
                   }}>Increase Version</button>
               </div>
    }
} 
*/

class App extends Component{
    state = {
        parentVersion : 10
    }
    render(){
        return <div>
                   <h1>App Component : version { this.state.parentVersion }</h1>
                   <Child version={ this.state.parentVersion }/>
                   <Second version={ this.state.parentVersion }/>
                   <button onClick={()=>{ this.setState({ parentVersion : this.state.parentVersion + 1 })}}>Increase Version</button>
               </div>
    }
}

export default App;