import React, { Component } from "react";

// props are immutable and can not be modified by child Component;

class Child extends Component{
    state = {
        power : 0
    }
    inputRef = React.createRef();
    /* 
    constructor(){
        super();
        this.increasePowerButtonClick = this.increasePowerButtonClick.bind(this);
    } 
    increasePowerButtonClick(){
        this.setState({ power : this.state.power + 1 })
    }
    */
    increasePowerButtonClick = () => {
        this.setState(
        function(currentState, currentProps){
            // console.log(arguments[0], arguments[1])
            return { power : currentState.power + 1 }
        }, 
        function(){
            console.log(this.state.power);
        });
       
    }
    increasePowerInputRange = (evt) => {
        this.setState({ power : Number(evt.target.value) })
    }
    increasePowerInputNumber = () => {
        this.setState({ power : Number(this.inputRef.current.value) })
    }
    render(){
        return <div style={ { border : "1px solid grey", margin : "10px", padding : "10px"} } >
                   <h2>Child Component</h2>
                   <h3>Version is { this.props.version }</h3>
                   <h3>Power is { this.state.power }</h3>
                   {/* <button onClick={ this.increasePowerButtonClick.bind(this) }>Increase Power</button> */}
                   <button onClick={ this.increasePowerButtonClick }>Increase Power</button>
                   <br />
                   <input value={this.state.power} onInput={ this.increasePowerInputRange } type="range" />
                   <br />
                   <input ref={this.inputRef} type="number" />
                   click button to set power
                   <button onClick={ this.increasePowerInputNumber }>Set Power</button>
               </div>
    }
}

export default Child;