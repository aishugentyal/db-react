import { Component } from "react";

class App extends Component{
    state = {
        power : 0,
        show : true
    }
    showhide = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
    render(){
        /* if(this.state.show){
            return <div>
                   <h1>App Component</h1>
                   <h2>Power is { this.state.power }</h2>
                   <label htmlFor="showhide">Show / Hide Terms and Conditions</label>
                   <input value={this.state.show} checked={ this.state.show } id="showhide" type="checkbox" onChange={ this.showhide } />
                   <fieldset>
                    <legend>Terms and Conditions</legend>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perferendis quam architecto aliquid neque magnam explicabo consequatur, nihil ea dolor, veritatis consequuntur assumenda enim eveniet libero? Enim molestiae reprehenderit ratione ut?
                    </p>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore enim facilis in officiis. Saepe atque error totam at odio voluptatum assumenda consequatur vitae quisquam? Quo laudantium omnis repudiandae quia labore?
                    </p>
                    <p>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nemo asperiores aliquam animi aliquid. Dicta accusantium eius dolores aperiam temporibus eveniet eaque quae veniam. Voluptate dolor iste beatae deleniti quibusdam vel.
                    </p>
                   </fieldset>
               </div>
        }else{
            return <div>
                        <h1>App Component</h1>
                        <h2>Power is { this.state.power }</h2>
                        <label htmlFor="showhide">Show / Hide Terms and Conditions</label>
                        <input id="showhide" type="checkbox" onChange={ this.showhide } />
                    </div>
        } */
        // trenary operator
        {/* 
        return <div>
            <h1>App Component</h1>
            <h2>Power is { this.state.power }</h2>
            <label htmlFor="showhide">Show / Hide Terms and Conditions</label>
            <input id="showhide" type="checkbox" onChange={ this.showhide } />
            { this.state.show ? <fieldset>
                <legend>Terms and Conditions</legend>
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perferendis quam architecto aliquid neque magnam explicabo consequatur, nihil ea dolor, veritatis consequuntur assumenda enim eveniet libero? Enim molestiae reprehenderit ratione ut?
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore enim facilis in officiis. Saepe atque error totam at odio voluptatum assumenda consequatur vitae quisquam? Quo laudantium omnis repudiandae quia labore?
                </p>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nemo asperiores aliquam animi aliquid. Dicta accusantium eius dolores aperiam temporibus eveniet eaque quae veniam. Voluptate dolor iste beatae deleniti quibusdam vel.
                </p>
            </fieldset> : ""}     
            </div>
        */}
        // logic operator 
           return <div>
            <h1>App Component</h1>
            <h2>Power is { this.state.power }</h2>
            <label htmlFor="showhide">Show / Hide Terms and Conditions</label>
            <input id="showhide" type="checkbox" onChange={ this.showhide } />
            { this.state.show && <fieldset>
                <legend>Terms and Conditions</legend>
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Perferendis quam architecto aliquid neque magnam explicabo consequatur, nihil ea dolor, veritatis consequuntur assumenda enim eveniet libero? Enim molestiae reprehenderit ratione ut?
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore enim facilis in officiis. Saepe atque error totam at odio voluptatum assumenda consequatur vitae quisquam? Quo laudantium omnis repudiandae quia labore?
                </p>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nemo asperiores aliquam animi aliquid. Dicta accusantium eius dolores aperiam temporibus eveniet eaque quae veniam. Voluptate dolor iste beatae deleniti quibusdam vel.
                </p>
            </fieldset> }     
            </div>
    }
}

export default App;