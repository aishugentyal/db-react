import { Component } from "react";

class FourthNestedChild extends Component{
    render(){
        return <div  style={ {border : "2px dotted grey", padding : "10px", margin : "10px"}}>
                   <h2>Fourth Nested Child Component</h2>
               </div>
    }
}

export default FourthNestedChild;