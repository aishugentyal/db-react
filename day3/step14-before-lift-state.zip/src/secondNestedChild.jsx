import { Component } from "react";

class SecondNestedChild extends Component{
    state = {
        version : Math.round( Math.random() * 1000 )
    }
    render(){
        return <div  style={ {border : "2px dotted grey", padding : "10px", margin : "10px"}}>
                   <h2>Second Nested Child Component</h2>
                   <h3>Version { this.state.version }</h3>
               </div>
    }
}

export default SecondNestedChild;