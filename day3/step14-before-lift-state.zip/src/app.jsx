import { Component } from "react";
import FirstChildComp from "./firstChild";
import SecondChildComp from "./secondChild";

class App extends Component{
    render(){
        return <div style={ {border : "2px dotted grey", padding : "10px", margin : "10px"} }>
                   <h1>App Component</h1>
                   <FirstChildComp/>
                   <SecondChildComp/>
               </div>
    }
}

export default App;