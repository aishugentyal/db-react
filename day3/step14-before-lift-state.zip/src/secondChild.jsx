import { Component } from "react";
import FourthNestedChild from "./fourthNestedChild";
import ThirdNestedChild from "./thirdNestedChild";

class SecondChildComp extends Component{
    render(){
        return <div  style={ {border : "2px dotted grey", padding : "10px", margin : "10px"}} >
                   <h2>SecondChildComp Component</h2>
                   <ThirdNestedChild/>
                   <FourthNestedChild/>
               </div>
    }
}

export default SecondChildComp;