import { Component } from "react";
import axios from "axios";

class App extends Component{
    state = {
        users : []
    }
    componentDidMount(){
       /* 
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then(res=>{
           // console.log(res.data);
           this.setState({
            users : res.data
           })
        })
        .catch(err=>{
            console.log("Error", err);
        }) 
        */
       axios.get("https://reqres.in/api/users?page=1")
       .then(res=>{
          // console.log(res.data);
          this.setState({
           users : res.data.data
          })
       })
       .catch(err=>{
           console.log("Error", err);
       }) 
    }
    render(){
        return <div>
                   <h1>App Component</h1>
                   <ol>{
                        this.state.users.map(val => <li key={val.id}>
                            <img width="50" src={val.avatar} alt={val.first_name} />
                            { val.first_name+" "+val.last_name } | 
                            eMail { val.email }
                            </li>)
                    }</ol>
               </div>
    }
}

export default App;
