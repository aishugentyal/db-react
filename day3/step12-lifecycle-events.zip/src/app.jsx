
import { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    state = {
        appPower : 0
    }
    constructor(){
        super();
        console.log("App Component's constructor was called");
    }
    componentDidMount(){
        console.log("App Component's componentDidMount was called");
    }
    render(){
        console.log("App Component's render was called");
        return <div>
                   <h1>App Component | App Power is : {this.state.appPower}</h1>
                   <button onClick={()=> this.setState({ appPower : this.state.appPower + 1 })}>Increase App Power</button>
                   { this.state.appPower < 11 && <ChildComp apppower={ this.state.appPower }/> }
               </div>
    }
}

export default App;