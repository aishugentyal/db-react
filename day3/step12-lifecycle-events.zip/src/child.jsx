import { Component } from "react";

class ChildComp extends Component{
    undo = [];
    state = {
        childPower : 0
    }
    constructor(){
        super();
        
        this.state = {
            childPower : 5
        };
        console.log("ChildComp's constructor was called");
        console.log("ChildComp's state of childPower was ", this.state.childPower);

    }
    static getDerivedStateFromProps(currentProp, currentState){
        // console.log(arguments[0], arguments[1])
        console.log("ChildComp's getDerivedStateFromProps was called");
        return {
            childPower : currentProp.apppower * 2
        };
    }
    componentDidMount(){
        // api calls
        console.log("ChildComp's componentDidMount was called");
    }
    shouldComponentUpdate(currentProp, currentState){
        console.log("ChildComp's shouldComponentUpdate was called");
        if(currentProp.apppower > 10){
            return false
        }else{
            return true
        }
    }
    getSnapshotBeforeUpdate(currentProp, currentState){
        console.log("ChildComp's getSnapshotBeforeUpdate was called");
        return {
            props : currentProp,
            state : currentState
        }
    }
    componentDidUpdate(currentProp, currentState, snapshot){
        console.log("ChildComp's componentDidUpdate was called");
        // console.log(currentProp, currentState, snapshot);
        this.undo.push(snapshot);
        console.log(this.undo.length, this.undo);
    }
    componentWillUnmount(){
        console.log("ChildComp's componentWillUnmount was called");
    }
    render(){
        console.log("ChildComp's render was called");
        return <div>
                   <h2>Child Component</h2>
                   <h3>App's Power : { this.props.apppower }</h3>
                   <h3>Child's Power : { this.state.childPower }</h3>
               </div>
    }
}

export default ChildComp;