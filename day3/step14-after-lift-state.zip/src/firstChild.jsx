import { Component } from "react";
import FirstNestedChild from "./firstNestedChild";
import SecondNestedChild from "./secondNestedChild";

class FirstChildComp extends Component{
   
    render(){
        return <div style={ {border : "2px dotted grey", padding : "10px", margin : "10px"}} >
                   <h2>FirstChildComp Component</h2>
                   <FirstNestedChild { ...this.props }/>
                   <SecondNestedChild { ...this.props }/>
               </div>
    }
}

export default FirstChildComp;