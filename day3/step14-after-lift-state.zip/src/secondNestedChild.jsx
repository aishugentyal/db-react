import { Component } from "react";

class SecondNestedChild extends Component{
    
    render(){
        return <div  style={ {border : "2px dotted grey", padding : "10px", margin : "10px"}}>
                   <h2>Second Nested Child Component</h2>
                   <h3>Version { this.props.version }</h3>
               </div>
    }
}

export default SecondNestedChild;