import { Component } from "react";

class FirstNestedChild extends Component{
   
    render(){
        return <div  style={ {border : "2px dotted grey", padding : "10px", margin : "10px"}} >
                   <h2>First Nested Child Component</h2>
                   <h3>Version { this.props.version }</h3>
               </div>
    }
}

export default FirstNestedChild;