import { Component } from "react";
import FirstFun from "./first.fun";
import UseEffectHookComp from "./useEffectHookComp";
import UseStateHookComp from "./useStateHookComp";

class App extends Component{
    state = {
        power : 0,
        version : 0,
        show : true
    }
    render(){
        return <div>
                   <h1>App Component</h1>
                   <FirstFun title="First Component" version={101} power={10}/>
                   <button onClick={()=> this.setState({ power : this.state.power + 1 })}>Increase Power</button>
                   <button onClick={()=> this.setState({ version : 100 })}>Change Version</button>
                   <button onClick={()=> this.setState({ show : !this.state.show })}>Show / Hide</button>
                   <hr />
                   <UseStateHookComp/>
                  { this.state.show &&  <UseEffectHookComp version={ this.state.version } power={ this.state.power }/>}
               </div>
    }
}

export default App;