let FirstFun=({title, version, power})=>{
    
    /* 
    let title = props.title;
    let version = props.version;
    let power = props.power; 
    */

    // let {title, version, power} = props;

    return <div>
                <h2>First Function Component</h2>
                <h3>Title : { title }</h3>
                <h3>Version : { version }</h3>
                <h3>Power : { power }</h3>
            </div>
}

export default FirstFun;