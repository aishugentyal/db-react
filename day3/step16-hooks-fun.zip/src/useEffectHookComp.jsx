import { useEffect } from "react";
var UseEffectHookComp = ({power, version})=>{
    /* 
    // Mount
    useEffect(function(){
        console.log("UseEffectHookComp was mounted")
    },[]);
    // Update
    useEffect(function(){
        console.log("UseEffectHookComp's power was updated : power now is ", power )
    },[ power, version ]);
    // UnMount
    useEffect(function(){
       return ()=>{
        console.log("UseEffectHookComp was unmounted" )
       }
    },[]); 
    */
    useEffect(()=>{
       console.log("UseEffectHookComp was mounted");
       console.log("UseEffectHookComp's power was updated : power now is ", power );
       return ()=>{
        console.log("UseEffectHookComp was unmounted" );
       }
    },[power]); 
    return <div>
                <h2>Use Effect Hook</h2>
                <h3>Power is { power }</h3>
                <h3>Version is { version }</h3>
            </div>
};
export default UseEffectHookComp;