import React, { useState } from "react";
import { useRef } from "react";

let UseStateHookComp = ()=>{
    // console.log( useState() );
    // let [power, setPower] = useState(0);
    /*  let increasePower = () => {
        setPower(power+1)
    } */
    let [avengers, addAvenger] = useState([]);
    /* 
    let fName = React.createRef();
    let lName = React.createRef(); 
    */
   let fName = useRef();
   let lName = useRef();
    let clickHanlder = () =>{
        addAvenger([...avengers, { firstname : fName.current.value, lastname : lName.current.value }]);
        fName.current.value = "";
        lName.current.value = "";
    }
    return <div>
               <h2>UseState Hook</h2>
              {/*   <h3>Power is : { power }</h3> */}
              {/* <button onClick={()=> setPower(power+1)}>Increase Power</button> */}
              {/*  <button onClick={ increasePower }>Increase Power</button> */}
              <label htmlFor="fname">First Name 
                <input id="fname" ref={ fName } type="text" />
              </label>
              <br />    
              <label htmlFor="lname">Last Name 
                <input id="lname" ref={ lName } type="text" />
              </label>
              <br />    
              <button onClick={ clickHanlder }>Add Avenger</button>
              <ol>
                {
                    avengers.map((val, idx)=>{
                        return <li key={idx}>{ val.firstname+" "+val.lastname }</li>
                    })
                }
              </ol>
           </div>
};

export default UseStateHookComp;