import { Component } from "react";
class ErrorManager extends Component{
    state = {
        hasError : false,
        errorMessage : ''
    }
    componentDidCatch(error, errorComp){
        this.setState({
            hasError : true,
            errorMessage : error+""
        })
    }
    render(){
        if(this.state.hasError){
            return <div>
                        <h2>Hero is weak...</h2>
                        <h3>{ this.state.errorMessage } because power is less</h3>
                   </div>
        }else{
            return this.props.children;
        }
    }
}
export default ErrorManager;