import { Component } from "react";
import ErrorManager from "./errorManager";
import HeroComp from "./hero";

class App extends Component{
    render(){
        return <div>
                   <h1>App Component</h1>
                    <ErrorManager>
                        <HeroComp power={5}/>
                    </ErrorManager>
                    <ErrorManager>
                        <HeroComp power={6}/>
                    </ErrorManager>
                    <ErrorManager>
                        <HeroComp power={7}/>
                    </ErrorManager>
                    <ErrorManager>
                        <HeroComp power={4}/>
                    </ErrorManager>            
               </div>
    }
}

export default App;