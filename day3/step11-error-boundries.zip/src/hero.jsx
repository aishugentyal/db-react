import { Component } from "react";

class HeroComp extends Component{
    render(){
       if(this.props.power < 5){
            throw new Error("Hero can't participate");
       }else{
         return <div>
                    <h2>HeroComp Component Power is { this.props.power }</h2>
                </div>
       }
    }
}

export default HeroComp;