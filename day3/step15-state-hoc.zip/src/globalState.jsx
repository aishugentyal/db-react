import { Component } from "react"

let WithGlobalState = (OriginalComp)=>{
    class TempComp extends Component{
        state = {
            version : 350
        }
        render(){
            return <OriginalComp { ...this.state }/>
        }
    }
    return TempComp
};

export default WithGlobalState;