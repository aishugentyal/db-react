/* 
import { connect } from "react-redux";
import { addHero } from "../redux";

let HeroHookComp = (props)=> {
    return <div>
                <h1>Hero Hook Comp Component</h1>
                <h2>Total Number of Avengers : { props.numberOfHeroes } </h2>
                <button onClick={ props.addHero }>Add Avenger</button>
            </div>
}

const mapStateToProps = (state)=>{
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}
const mapDispatchToProps = (dispatch)=>{
    return {
        addHero : ()=> dispatch( addHero() )
    }
}

export default connect( mapStateToProps, mapDispatchToProps)(HeroHookComp); 
*/

import { useDispatch, useSelector } from "react-redux";
import { addHero } from "../redux";

let HeroHookComp = ()=> {
    const numberOfHeroes = useSelector( state => state.numberOfHeroes );
    const dispatch = useDispatch();
    return <div>
                <h1>Hero Hook Comp Component</h1>
                <h2>Total Number of Avengers : { numberOfHeroes } </h2>
                <button onClick={ ()=> dispatch( addHero() ) }>Add Avenger</button>
            </div>
}


export default HeroHookComp;