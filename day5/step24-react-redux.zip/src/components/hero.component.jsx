import { Component } from "react";
import { connect } from "react-redux";
import { addHero } from "../redux";

class HeroComp extends Component{
    render(){
        return <div>
                   <h1>HeroComp Component</h1>
                   <h2>Total Number of Avengers : { this.props.numberOfHeroes } </h2>
                   <button onClick={ this.props.addHero }>Add Avenger</button>
               </div>
    }
}

const mapStateToProps = (state)=>{
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}
const mapDispatchToProps = (dispatch)=>{
    return {
        addHero : ()=> dispatch( addHero() )
    }
}

export default connect( mapStateToProps, mapDispatchToProps)(HeroComp);