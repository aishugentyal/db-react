import { legacy_createStore } from "redux";
import heroReducer from "./hero/reducers/hero.reducer";

const store = legacy_createStore(heroReducer);

export default store;