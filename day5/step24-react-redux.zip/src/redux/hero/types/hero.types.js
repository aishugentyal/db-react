export const ADD_HERO = "ADD_HERO";
