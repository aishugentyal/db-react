import { Component } from "react";
import { Provider } from "react-redux";
import HeroComp from "./components/hero.component";
import HeroHookComponent from "./components/hero.hook.component";
import store from "./redux/store";
class App extends Component{
    render(){
        return <div className="container">
                   <h1>React Redux Application</h1>
                   <Provider store={store}>
                    <HeroComp/>
                    <HeroHookComponent/>
                   </Provider>
               </div>
    }
}
export default App;