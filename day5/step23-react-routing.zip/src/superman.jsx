import { useParams } from "react-router-dom";

let Superman = ()=> {
    let params = useParams();
    return <div>
                <h2>Superman Component</h2>
                <h3>Power is { params.power } </h3>
            </div>
}

export default Superman;