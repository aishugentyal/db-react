import { Component } from "react";
import { Outlet } from "react-router-dom";

class WonderWomen extends Component{
    render(){
        return <div>
                   <h2>WonderWomen Component</h2>
                   <Outlet/>
               </div>
    }
}

export default WonderWomen;