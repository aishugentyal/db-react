import { Component } from "react";

class WonderWomenMovie1 extends Component{
    render(){
        return <div>
                   <h2>WonderWomen the Movie</h2>
               </div>
    }
}

export default WonderWomenMovie1;