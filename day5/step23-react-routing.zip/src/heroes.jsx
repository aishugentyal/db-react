import { Component } from "react";

class Heroes extends Component{
    render(){
        return <div>
                   <h2>Heroes Component</h2>
               </div>
    }
}

export default Heroes;
