import { Component } from "react";

class WonderWomenMovie2 extends Component{
    render(){
        return <div>
                   <h2>WonderWomen 1984</h2>
               </div>
    }
}

export default WonderWomenMovie2;