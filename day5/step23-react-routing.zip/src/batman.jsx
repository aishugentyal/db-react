import { Component } from "react";

class Batman extends Component{
    render(){
        return <div>
                   <h2>Batman Component</h2>
               </div>
    }
}

export default Batman;