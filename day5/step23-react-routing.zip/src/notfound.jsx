import { Component } from "react";

class NotFound extends Component{
    render(){
        return <div>
                   <h2>NotFound Component</h2>
               </div>
    }
}

export default NotFound;