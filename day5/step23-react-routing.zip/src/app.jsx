import React,{ Component, Suspense } from "react";
import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import "./mystyle.css";
import Heroes from "./heroes";
// import Batman from "./batman";
// import NotFound from "./notfound";
// import Superman from "./superman";
// import WonderWomen from "./wonderwomen";
// import WonderWomenMovie1 from "./wonderwomenmovie1";
// import WonderWomenMovie2 from "./wonderwomenmovie2";

 let Batman = React.lazy( ()=> import("./batman") );
 let NotFound  = React.lazy( ()=> import("./notfound"));
 let Superman  = React.lazy( ()=> import("./superman"));
 let WonderWomen  = React.lazy( ()=> import("./wonderwomen"));
 let WonderWomenMovie1 = React.lazy( ()=> import("./wonderwomenmovie1")) ;
 let WonderWomenMovie2 = React.lazy( ()=> import("./wonderwomenmovie2")) ;

class App extends Component{
    state = {
        power : 0
    }
    render(){
        return <div className="container"> 
                   <h1>App Component | { this.state.power }</h1>
                   <input type="range" onInput={(evt)=> this.setState({power : Number(evt.target.value)})} />
                   <hr />
                  <BrowserRouter>
                  {/*  <ul>
                    <li> <Link to={"/"}>Heroes Home</Link> </li>
                    <li> <Link to={"/batman"}>Batman</Link> </li>
                    <li> <Link to={"/superman"}>Superman</Link> </li>
                    <li> <Link to={"/wonderwomen"}>Wonder women</Link> </li>
                    <li> <Link to={"/flash"}> Flash </Link> </li>
                    <li> <Link to={"/ironamn"}> Ironman </Link> </li>
                    <li> <Link to={"/hulk"}> Hulk </Link> </li>
                   </ul> */}
                    <ul>
                    <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/"}>Heroes Home</NavLink> </li>
                    <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/batman"}>Batman</NavLink> </li>
                    <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/superman/"+this.state.power}>Superman</NavLink> </li>
                    <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/wonderwomen"}>Wonder women</NavLink> 
                        <ul>
                            <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/wonderwomen/movie1"}>Movie 1</NavLink> </li>
                            <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/wonderwomen/movie2"}>Movie 2</NavLink> </li>
                        </ul>
                    </li>
                    <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/flash"}> Flash </NavLink> </li>
                    <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/ironamn"}> Ironman </NavLink> </li>
                    <li> <NavLink className={ ({ isActive })=> isActive ? 'selectedbox' : 'linkbox'  } to={"/hulk"}> Hulk </NavLink> </li>
                   </ul>
                    <Routes>
                        <Route path="/" element={ <Heroes/> } />
                        <Route path="/batman" element={ <Suspense fallback={<>...loading</>}> <Batman/> </Suspense> } />
                        <Route path="/superman/:power" element={ <Suspense fallback={<>...loading</> }> <Superman/>  </Suspense> } />
                        <Route path="/wonderwomen" element={ <Suspense fallback={<>...loading</> }> <WonderWomen/>  </Suspense> }>
                            <Route path="movie1" element={  <Suspense fallback={<>...loading</> }> <WonderWomenMovie1/>  </Suspense> }/>
                            <Route path="movie2" element={  <Suspense fallback={<>...loading</> }> <WonderWomenMovie2/>  </Suspense> }/>
                        </Route>
                        <Route path="/flash" element={ <Suspense fallback={<>...loading</> }> <Batman/> </Suspense>  } />
                        <Route path="*" element={ <Suspense fallback={<>...loading</> }> <NotFound/> </Suspense> } />
                    </Routes>
                  </BrowserRouter>
               </div>
    }
}

export default App;

{/* 
<BrowserRouter>
    <Routes>
        <Route path="/" element={<h2>Home page</h2>} />
        <Route path="/about" element={<h2>About page</h2>} />
    </Routes>
</BrowserRouter> 
*/}