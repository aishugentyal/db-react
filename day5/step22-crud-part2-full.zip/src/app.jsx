import axios from "axios";
import { useEffect, useState } from "react";

let App = ()=>{
    let [heroes, setHeroes] = useState([]);
    let [showhide, setShowHide] = useState(false);
    let [nhero, setNewHero] = useState({  title: "", firstname: "", lastname: "",  power: 0, city: "" });
    let [ehero, updateHeroInfo] = useState({ _id:0,  title: "", firstname: "", lastname: "",  power: 0, city: "" });
    // let [ehero, updateHeroInfo] = useState({});
    
    let url = "http://localhost:5050";

    let refresh = ()=>{
        axios.get(url+"/data")
        .then( (res)=>{
            // console.log(res.data);
            setHeroes(res.data);
        }).catch((err)=>{
            console.log("Error ", err)
        }).finally(()=>{
            console.log("API call completed")
        })
    };

    let addHandler = (evt)=>{
        setNewHero({
            ...nhero,
            [evt.target.id] : evt.target.value
        })
    };
    
    let editHandler = (evt)=>{
        updateHeroInfo({
            ...ehero,
            [evt.target.getAttribute("data-edit_info")] : evt.target.value
        })
    };
    
    useEffect(()=> refresh() ,[]);

    let addHeroHandler = ()=>{
        axios
        .post(url+"/data",nhero)
        .then( res => refresh() )
        .catch(err=>console.log(err))
    }

    let deleteHeroHandler = (heroid)=>{
        axios.delete(url+"/delete/"+heroid).then( res => {
            console.log(res); 
            refresh();
        });
    };

    let editSelectedHeroHandler = (heroid)=>{
        axios.get(url+"/edit/"+heroid)
        .then( res => {
            updateHeroInfo(res.data);
            setShowHide(false);
        })
        .catch(err => console.log("Error ", err));
    }

    let updateHeroHandler = ()=>{
        axios.post(url+"/edit/"+ehero._id, ehero )
        .then( res => {
            refresh();
            setShowHide(true);
        })
        .catch(err => console.log("Error ", err));
    }

    return <div className="container">
        { showhide && <div>
                <h1>Add Hero</h1>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Hero's Title</label>
                    <input onChange={ addHandler } value={ nhero.title } className="form-control" id="title" />
                </div>
                <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">Hero's First Name</label>
                    <input onChange={ addHandler } value={ nhero.firstname } className="form-control" id="firstname" />
                </div>
                <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">Hero's Last Name</label>
                    <input onChange={ addHandler } value={ nhero.lastname } className="form-control" id="lastname" />
                </div>
                <div className="mb-3">
                    <label htmlFor="power" className="form-label">Hero's Power</label>
                    <input onChange={ addHandler } value={ nhero.power } type="range" min="0" max="10" step="1" className="form-control" id="power" />
                </div>
                <div className="mb-3">
                    <label htmlFor="city" className="form-label">Hero's City</label>
                    <input onChange={ addHandler } value={ nhero.city } className="form-control" id="city" />
                </div>
                <button onClick={ addHeroHandler } type="submit" className="btn btn-primary">Add Hero</button>
            </div>  
            }
            {/* --------------------- */}
            { !showhide && <div>
                <h1>Edit Hero</h1>
                <div className="mb-3">
                    <label htmlFor="e_title" className="form-label">Edit Hero's Title</label>
                    <input onChange={ editHandler } value={ ehero.title } className="form-control" data-edit_info="title" id="e_title" />
                </div>
                <div className="mb-3">
                    <label htmlFor="e_firstname" className="form-label">Edit Hero's First Name</label>
                    <input onChange={ editHandler } value={ ehero.firstname } className="form-control" data-edit_info="firstname" id="e_firstname" />
                </div>
                <div className="mb-3">
                    <label htmlFor="e_lastname" className="form-label">Edit Hero's Last Name</label>
                    <input onChange={ editHandler } value={ ehero.lastname } className="form-control" data-edit_info="lastname" id="e_lastname" />
                </div>
                <div className="mb-3">
                    <label htmlFor="e_power" className="form-label">Edit Hero's Power</label>
                    <input onChange={ editHandler } value={ ehero.power } type="range" min="0" max="10" step="1" className="form-control" data-edit_info="power" id="e_power" />
                </div>
                <div className="mb-3">
                    <label htmlFor="e_city" className="form-label">Edit Hero's City</label>
                    <input onChange={ editHandler } value={ ehero.city } className="form-control" data-edit_info="city" id="e_city" />
                </div>
                <button  onClick={ updateHeroHandler }  type="submit" className="btn btn-primary">Update Info</button>
            </div>
                }
            {/* --------------------- */}
            <div>
                <h1>Hero's List</h1>
                <table className="table table-responsive table-striped">
                <thead>
                    <tr>
                        <th>Sl #</th>
                        <th>Title</th>
                        <th>Full Name</th>
                        <th>Power</th>
                        <th>City</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>{ heroes.map( (hero,idx) => <tr key={hero._id}>
                                                        <td>{ idx + 1 }</td>
                                                        <td>{ hero.title }</td>
                                                        <td>{ hero.firstname+" "+hero.lastname } </td>
                                                        <td>{ hero.power }</td>
                                                        <td>{ hero.city }</td>
                                                        <td>
                                                            <button onClick={ ()=> editSelectedHeroHandler(hero._id) } className="btn btn-warning"> Edit { hero.title }'s info </button>
                                                        </td>
                                                        <td>
                                                            <button onClick={ ()=> deleteHeroHandler(hero._id) } className="btn btn-danger"> Delete { hero.title } </button>
                                                        </td>
                                                    </tr>) }
                </tbody>
            </table>
            </div>
            <ul>
                <li>Hero Title { nhero.title }</li>
                <li>Hero First Name { nhero.firstname }</li>
                <li>Hero Last Name { nhero.lastname }</li>
                <li>Hero Power { nhero.power }</li>
                <li>Hero City { nhero.city }</li>
            </ul>
            </div>
}
export default App;


