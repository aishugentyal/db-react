import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{
    /* 
    static defaultProps = {
        title : "Title is Missing",
        version : 0
    } 
    */
   static propTypes = {
        version : PropTypes.number.isRequired,
        title : PropTypes.string.isRequired
   }
    render(){
        return <div style={ { border : "1px solid grey ", margin : "10px", padding : "10px"} }>
                    <h2>Child Component</h2>
                    <h3>Version : { this.props.version }</h3>
                    <h3>Title : { this.props.title }</h3>
                </div>
    }
};

/* 
ChildComp.defaultProps = {
    title : "Title is Missing",
    version : 0
};
*/
export default ChildComp