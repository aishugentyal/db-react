import  { Component } from "react";
import ChildComp from "./child.component";

class App extends Component{
    render(){
        return <div>
                    <h1> Props in React </h1>
                    <ChildComp version={101} title="Child Component 1"/>
                    <ChildComp version={102} title="Child Component 2"/>
                    <ChildComp version={103} title="Child Component 3"/>
                    <ChildComp version={201} title="Child Component 4"/>
                    <ChildComp version={202} title="Child Component 5"/>
                </div>
    }
}

export default App;