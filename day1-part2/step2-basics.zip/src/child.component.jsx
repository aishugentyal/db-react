import { Component } from "react";

class ChildComp extends Component{
    render(){
        return <>
            <h2>{ this.props.title } Version : { this.props.version }</h2>
            <ol>
                { this.props.herolist.map((val,idx,arr)=> <li key={idx}>{ val }</li> ) }
            </ol>
        </>
    }
};

export default ChildComp;