import  { Component, Fragment, createRef } from "react";
import ChildComp from "./child.component";
/*
React.Fragment
Fragment
<></>
*/
class Elm extends Component{
    avengers = [];
    justiceleague = ['Batman','Superman','Wonder Women','Aquaman','Hawkeye', 'Flash'];
    indicheroes = ['Krrish','Shaktiman','Chota Bheem','Chakra','Junior G'];
    version = 0;
    versionRef = createRef();
    avengersRef = createRef();
    clickHandler(){
        // alert("you clicked me");
        // this.version = this.version+1;
        // console.log(this.version);
        this.version = this.versionRef.current.value;
        // console.log(this.versionRef);
        this.forceUpdate();
    }
    addAvenger(){
        this.avengers.push(this.avengersRef.current.value);
        this.avengersRef.current.value = '';
        this.forceUpdate();
    }
    render(){
        return <>
                <h1> Welcome to your life </h1>
                {/* <button onClick={ this.clickHandler.bind(this) } >Increase Version</button> */}
                <input ref={this.avengersRef} />
                <button onClick={this.addAvenger.bind(this)}>Add Avenger</button>
                <br />
                <input ref={this.versionRef} type="range" />
                <button onClick={this.clickHandler.bind(this)}>Increase Version</button>
                <ChildComp version={ this.version } herolist={this.avengers} title="Avengers"/>
                <ChildComp version={ this.version } herolist={this.justiceleague} title="Justice League"/>
                <ChildComp version={ this.version } herolist={this.indicheroes} title="Indic Heroes"/>
               </>
    }
}

export default Elm;