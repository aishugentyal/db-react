import { createRoot } from "react-dom/client";
import Elm from "./app";

// let elm = <h1> Welcome to your life </h1>;

// let Elm = ()=> <h1> Welcome to your life there's no turning back </h1>;


createRoot(document.getElementById("root")).render(<Elm/>);
