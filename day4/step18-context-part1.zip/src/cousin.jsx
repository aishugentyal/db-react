import { Component } from "react";
import { FamilyContext } from "./contexts/family.context";
import { PowerContext } from "./contexts/power.context";

class CousinComp extends Component{
    render(){
        return <div  style={ {border:"2px solid grey", padding : "10px", margin:"10px"} }>
                   <h1>Cousin Component</h1>
                   <FamilyContext.Consumer>{ (val)=> <h2>Version is { val }</h2> }</FamilyContext.Consumer>
                   <PowerContext.Consumer>{ (val)=> <h2>Power is { val }</h2> }</PowerContext.Consumer>
               </div>
    }
}

export default CousinComp;