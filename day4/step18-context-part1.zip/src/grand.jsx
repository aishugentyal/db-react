import { Component } from "react";
import { FamilyContext } from "./contexts/family.context";
import { PowerContext } from "./contexts/power.context";
import CousinComp from "./cousin";
import ParentComp from "./parent";

class GrandParentComp extends Component{
    state = {
        version : 0,
        power : 0
    }
    render(){
        return <div style={ {border:"2px solid grey", padding : "10px", margin:"10px"} }>
                   <h1>Grand Parent Component | { this.state.version }</h1>
                   <button onClick={()=> this.setState({ version : Math.round( Math.random() * 1000 )})}>Random Version</button>
                   <button onClick={()=> this.setState({ power : this.state.power + 1 })}>Increase Power</button>
                   <hr />
                  {/*  <FamilyContext.Provider value={ this.state }>
                       <ParentComp/>
                       <CousinComp/>
                   </FamilyContext.Provider> */}
                   <FamilyContext.Provider value={ this.state.version }>
                       <ParentComp/>
                       <PowerContext.Provider value={ this.state.power }>
                            <CousinComp/>
                       </PowerContext.Provider>
                   </FamilyContext.Provider> 
               </div>
    }
}

export default GrandParentComp;