import { Component } from "react";
import { FamilyContext } from "./contexts/family.context";

class ChildComp extends Component{
    render(){
        return <div style={ {border:"2px solid grey", padding : "10px", margin:"10px"} }>
                   <h1>Child Component</h1>
                   <FamilyContext.Consumer>{ (val)=> {
                    return <div>
                            <h2>Version is { val }</h2>
                                {/* <h2>Version is { val.version }</h2> */}
                               {/*  <h2>Power is { val.power }</h2> */}
                            </div>
                   } }</FamilyContext.Consumer>
               </div>
    }
}

export default ChildComp;