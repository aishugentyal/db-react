import React from "react";
let PowerContext = React.createContext();
export { PowerContext };