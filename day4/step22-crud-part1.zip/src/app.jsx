import axios from "axios";
import { useEffect } from "react";
import { useState } from "react";

let App = ()=>{
    let [heroes, setHeroes] = useState([]);
    let [nhero, setNewHero] = useState({  title: "", firstname: "", lastname: "",  power: 0, city: "", });

    let refresh = ()=>{
        axios.get("http://localhost:5050/data")
        .then( (res)=>{
            // console.log(res.data);
            setHeroes(res.data);
        }).catch((err)=>{
            console.log("Error ", err)
        }).finally(()=>{
            console.log("API call completed")
        })
    };

    let addHandler = (evt)=>{
        setNewHero({
            ...nhero,
            [evt.target.id] : evt.target.value
        })
    };
    
    useEffect(()=> refresh() ,[]);

    let addHeroHandler = ()=>{
        axios
        .post("http://localhost:5050/data",nhero)
        .then( res => refresh() )
        .catch(err=>console.log(err))
    }

    return <div className="container">
            <div>
                <h1>Add Hero</h1>
                <div className="mb-3">
                    <label htmlFor="title" className="form-label">Hero's Title</label>
                    <input onChange={ addHandler } value={ nhero.title } className="form-control" id="title" />
                </div>
                <div className="mb-3">
                    <label htmlFor="firstname" className="form-label">Hero's First Name</label>
                    <input onChange={ addHandler } value={ nhero.firstname } className="form-control" id="firstname" />
                </div>
                <div className="mb-3">
                    <label htmlFor="lastname" className="form-label">Hero's Last Name</label>
                    <input onChange={ addHandler } value={ nhero.lastname } className="form-control" id="lastname" />
                </div>
                <div className="mb-3">
                    <label htmlFor="power" className="form-label">Hero's Power</label>
                    <input onChange={ addHandler } value={ nhero.power } type="range" min="0" max="10" step="1" className="form-control" id="power" />
                </div>
                <div className="mb-3">
                    <label htmlFor="city" className="form-label">Hero's City</label>
                    <input onChange={ addHandler } value={ nhero.city } className="form-control" id="city" />
                </div>
                <button onClick={ addHeroHandler } type="submit" className="btn btn-primary">Add Hero</button>
            </div>
            {/* --------------------- */}
            <div>
                <h1>Hero's List</h1>
                <table className="table table-responsive table-striped">
                <thead>
                    <tr>
                        <th>Sl #</th>
                        <th>Title</th>
                        <th>Full Name</th>
                        <th>Power</th>
                        <th>City</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>{ heroes.map( (hero,idx) => <tr key={hero._id}>
                                                        <td>{ idx + 1 }</td>
                                                        <td>{ hero.title }</td>
                                                        <td>{ hero.firstname+" "+hero.lastname } </td>
                                                        <td>{ hero.power }</td>
                                                        <td>{ hero.city }</td>
                                                        <td>
                                                            <button className="btn btn-warning"> Edit { hero.title }'s info </button>
                                                        </td>
                                                        <td>
                                                            <button className="btn btn-danger"> Delete { hero.title } </button>
                                                        </td>
                                                    </tr>) }
                </tbody>
            </table>
            </div>
            <ul>
                <li>Hero Title { nhero.title }</li>
                <li>Hero First Name { nhero.firstname }</li>
                <li>Hero Last Name { nhero.lastname }</li>
                <li>Hero Power { nhero.power }</li>
                <li>Hero City { nhero.city }</li>
            </ul>
            </div>
}
export default App;


