import { useReducer } from "react";
// import { useState } from "react";

let App = ()=>{

    /*     
    let [firstname, setFirstName] = useState("default");
    let [lastname, setLastName] = useState("default"); 
    */

   // store
   // intial state
   // reducerFunction (pure function)
   // dispatch

   let reducerFun = (state, action)=>{
    switch(action.type){
        case "SETFIRSTNAME" : return {...state, firstname : action.payload }
        case "SETLASTNAME" : return {...state, lastname : action.payload }
        case "SETPOWER" : return {...state, power : action.payload }
        case "SETCITY" : return {...state, city : action.payload }
        default : return state
    }
   };

   let [store, dispatch] = useReducer(reducerFun,{firstname : 'default', lastname : 'default', power : 0, city : ""})

    return <div>
                <h1>App Component</h1>
                <ul>
                    <li>First Name { store.firstname }</li>
                    <li>Last Name { store.lastname }</li>
                    <li>Power { store.power }</li>
                    <li>City { store.city }</li>
                </ul>
                <label htmlFor="fname">First Name </label>
                <input id="fname" onChange={(evt)=> dispatch({ type : "SETFIRSTNAME", payload : evt.target.value }) } />
                <br />
                <label htmlFor="lname">First Name </label>
                <input id="lname" onChange={(evt)=> dispatch({ type : "SETLASTNAME", payload : evt.target.value }) } /> 
                <br />
                <label htmlFor="power">Power </label>
                <input id="power" onChange={(evt)=> dispatch({ type : "SETPOWER", payload : Number(evt.target.value) }) } /> 
                <br />
                <label htmlFor="city">City </label>
                <input id="city" onChange={(evt)=> dispatch({ type : "SETCITY", payload : evt.target.value }) } /> 

                {/* 
                <label htmlFor="fname">First Name </label>
                <input id="fname" onChange={(evt)=> setFirstName(evt.target.value) } />
                <br />
                <label htmlFor="lname">First Name </label>
                <input id="lname" onChange={(evt)=> setLastName(evt.target.value) } /> 
                */}
            </div>
}

export default App;