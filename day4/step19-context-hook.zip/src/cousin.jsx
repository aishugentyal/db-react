import { useContext } from "react";
import { FamilyContext } from "./contexts/family.context";
import { PowerContext } from "./contexts/power.context";

let CousinComp = ()=>{
    let version = useContext(FamilyContext);
    let power = useContext(PowerContext);
    return <div  style={ {border:"2px solid grey", padding : "10px", margin:"10px"} }>
                <h1>Cousin Component</h1>
                {/*             
                <FamilyContext.Consumer>{ (val)=> <h2>Version is { val }</h2> }</FamilyContext.Consumer>
                <PowerContext.Consumer>{ (val)=> <h2>Power is { val }</h2> }</PowerContext.Consumer> 
                */}
                <h2>Version is { version }</h2> 
                <h2>Power is { power }</h2>
            </div>
}

export default CousinComp;