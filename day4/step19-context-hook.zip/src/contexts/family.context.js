import React from "react";
let FamilyContext = React.createContext();
/*
Provider
Consumer
*/

/*
let FamilyProvider = FamilyContext.Provider;
let FamilyConsumer = FamilyContext.Consumer;

export { FamilyProvider, FamilyConsumer }
*/

export { FamilyContext };