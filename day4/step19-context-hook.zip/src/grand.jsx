import { useState } from "react";
import { Component } from "react";
import { FamilyContext } from "./contexts/family.context";
import { PowerContext } from "./contexts/power.context";
import CousinComp from "./cousin";
import ParentComp from "./parent";

let GrandParentComp =()=>{
    let [version, setVersion] = useState(0);
    let [power, setPower] = useState(0);
    return <div style={ {border:"2px solid grey", padding : "10px", margin:"10px"} }>
                <h1>Grand Parent Component | { version }</h1>
                <button onClick={()=> setVersion( Math.round( Math.random() * 1000 ) )}>Random Version</button>
                <button onClick={()=> setPower( power + 1  )}>Increase Power</button>
                <hr />
                <FamilyContext.Provider value={ version }>
                    <ParentComp/>
                    <PowerContext.Provider value={ power }>
                        <CousinComp/>
                    </PowerContext.Provider>
                </FamilyContext.Provider> 
            </div>
}

export default GrandParentComp;