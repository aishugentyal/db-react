import { useContext } from "react";
import { FamilyContext } from "./contexts/family.context";

let ChildComp = ()=> {
    let version = useContext(FamilyContext);
    return <div style={ {border:"2px solid grey", padding : "10px", margin:"10px"} }>
                <h1>Child Component</h1>
                <h2>Version is { version }</h2>
            </div>
}

export default ChildComp;