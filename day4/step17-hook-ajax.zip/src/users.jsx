import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";

let UsersComp = ()=>{
    let [users, setUsers] = useState( [ { id: 1, name : "Bruce Wayne"} ] );
    useEffect(()=>{
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then(res => setUsers(res.data)).catch(err => console.log("Error ", err));
    },[])
    return <div>
                <h1>Users Component</h1>
                <ol>{ users.map(user => <li key={user.id}>{ user.name }</li>) }</ol>
           </div>
}

export default UsersComp;