import { Component } from "react";
import ClassChildComp from "./class-child.component";
import ClassPureComp from "./class-pure.component";
import FunChildComp from "./fun-child.component";
import MemoComp from "./memo-component";

class App extends Component{
    state = {
        power : 0,
        version : 0
    }
    render(){
        return <div>
                   <h1>App Component</h1>
                   <button onClick={()=> this.setState({ power : this.state.power + 1 })}>Increase Power</button>
                   <button onClick={()=> this.setState({ version : 101 })}>Change Version to 101</button>
                   <ClassChildComp { ...this.state }/>
                   <ClassPureComp { ...this.state }/>
                   <FunChildComp  { ...this.state }/>
                   <MemoComp { ...this.state }/>
               </div>
    }
}

export default App;