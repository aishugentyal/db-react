import React from "react";

let MemoComp = (props)=>{
    console.log("MemoChildComp was rendered ", Math.random());
    return <div>
                <h1>Memo Component</h1>
                <h2>Power { props.power }</h2>
                <h2>Version { props.version }</h2>
            </div>
}
export default React.memo( MemoComp );
